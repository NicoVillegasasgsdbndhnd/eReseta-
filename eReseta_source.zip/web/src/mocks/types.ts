

export type Role = 'patient' | 'doctor' | 'pharmacist' | 'admin' | 'staff'



export interface User {
  id: number
  name: string
  first_name?: string | null
  middle_name?: string | null
  last_name?: string | null
  gender?: 'male' | 'female' | 'other' | null
  email: string
  phone: string | null
  address: string | null
  role: Role
  status: 'active' | 'inactive'
  must_change_password?: boolean
  terms_accepted?: boolean
  profile_complete?: boolean
  profile_photo_url: string | null
  patient?: {
    id: number
  } | null
  doctor?: ({
    id: number
    specialization: string
    license_no: string
    ptr_no?: string | null
    s2_license?: string | null
    signature?: string | null
    prc_expiry: string | null
  } & DoctorCredentials) | null
  assigned_doctor?: {
    id: number
    specialization: string
    user?: { id: number; name: string }
  } | null
  staff_request?: {
    id: number
    status: 'pending' | 'approved' | 'rejected'
  } | null
  created_at: string
  updated_at: string
}



export interface StaffRequest {
  id: number
  status: 'pending' | 'approved' | 'rejected'
  created_at: string
  staff_user: { id: number; name: string; email: string }
}



export interface PatientActivation {
  activated: boolean
  link_sent: boolean
  expires_at: string | null
  expired: boolean
  hours_left: number
  reactivation_requested: boolean
  reactivation_requested_at: string | null
}

export interface Patient {
  id: number
  patient_code?: string
  user_id: number
  user?: User
  activation?: PatientActivation | null
  dob: string
  sex: 'male' | 'female'
  address: string
  philhealth_no: string | null
  contact: string
  preferred_language?: string | null
  known_allergies?: string | null
  gov_id_type?: string | null
  gov_id_no?: string | null
  hmo_provider?: string | null
  hmo_policy_no?: string | null
  hmo_group_no?: string | null
  copay?: string | null
  emergency_contact_name?: string | null
  emergency_contact_phone?: string | null
  emergency_contact_relation?: string | null
  created_at: string
  updated_at: string
}





export interface DoctorCredentials {
  suffix?: string | null
  gender?: 'male' | 'female' | 'other' | null
  date_of_birth?: string | null
  corporate_email?: string | null
  secure_phone?: string | null
  secretary_phone?: string | null
  clinic_email?: string | null
  trunkline_ext?: string | null
  profile_photo?: string | null
  signature_image?: string | null            // uploaded e-signature image URL
  philhealth_accreditation?: string | null   // PAN
  tin?: string | null                          // admin-only
  hospital_department?: string | null
  consultant_type?: string | null
  clinic_room_no?: string | null
  medical_society_affiliations?: string[] | null
  hmo_partners?: string[] | null
  clinic_available_days?: string[] | null
  consultation_fee?: string | number | null
  followup_fee?: string | number | null
  inpatient_fee?: string | number | null
  er_referral_fee?: string | number | null
}

export interface Doctor extends DoctorCredentials {
  id: number
  user_id: number
  user?: User
  license_no: string
  ptr_no?: string | null
  s2_license?: string | null
  signature?: string | null
  specialization: string
  prc_expiry: string
  created_at: string
  updated_at: string
}

export interface DoctorAvailability {
  doctor_id: number
  date: string
  slots: TimeSlot[]
}

export interface TimeSlot {
  time: string
  available: boolean
}



export type AppointmentStatus =
  | 'scheduled'
  | 'confirmed'
  | 'served'
  | 'rescheduled'
  | 'cancelled'

export type AppointmentType = 'consultation' | 'follow_up'

export interface Appointment {
  id: number
  patient_id: number | null
  doctor_id: number
  patient?: Patient | null
  doctor?: Doctor


  guest_name?: string | null
  guest_contact?: string | null
  guest_email?: string | null
  guest_dob?: string | null
  guest_sex?: 'male' | 'female' | 'other' | null
  display_name?: string | null
  is_guest?: boolean
  scheduled_at: string
  status: AppointmentStatus
  cancelled_by?: 'patient' | 'clinic' | null
  type: AppointmentType
  notes: string | null
  created_at: string
  updated_at: string
}

export interface AppointmentStatusHistory {
  id: number
  appointment_id: number
  from_status: AppointmentStatus | null
  to_status: AppointmentStatus
  changed_by: number
  changed_by_user?: User
  notes: string | null
  created_at: string
}



export interface PatientRecord {
  id: number
  patient_id: number
  doctor_id: number
  patient?: Patient
  doctor?: Doctor
  visit_date: string
  chief_complaint: string
  vital_signs?: Record<string, string> | null
  physical_exam?: Record<string, { status: string; notes: string }> | null
  diagnosis: string
  notes: string | null
  restriction_category?: string | null
  restricted_specialization?: string | null
  restriction_label?: string | null
  prescriptions?: Prescription[]
  diagnostic_orders?: DiagnosticOrder[]
  created_at: string
  updated_at: string
}

export type RestrictionCategory =
  | 'mental_health' | 'genetic' | 'substance_abuse' | 'vip' | 'patient_requested'



export interface DiagnosticTest {
  id: number
  name: string
  category: string | null
  modality: string | null      // imaging only: X-Ray, Ultrasound, ECG…
  body_region: string | null   // imaging only: Chest, Upper Extremities…
  is_available: boolean
}

export interface DiagnosticOrderItem {
  id: number
  test_name: string
  clinical_reason: string | null
}

export interface DiagnosticOrder {
  id: number
  reference_no: string
  patient_record_id: number
  doctor_id: number
  doctor?: Doctor
  ordered_at: string
  status: 'ordered' | 'completed' | 'cancelled'
  notes: string | null
  items: DiagnosticOrderItem[]
  created_at: string
}



export interface PatientConsent {
  id: number
  status: 'given' | 'withdrawn'
  notes: string | null
  consent_version: string
  recorded_at: string
  recorded_by?: string | null
}

export interface BreakGlassAlert {
  id: number
  patient_id: number
  patient_name?: string | null
  doctor_name?: string | null
  reason: string
  granted_at: string
  expires_at: string
  active: boolean
}



export type PrescriptionStatus = 'issued' | 'verified' | 'dispensed' | 'expired'

export interface PrescriptionItem {
  id: number
  prescription_id: number
  drug_name: string
  medicine_id?: number | null
  dosage: string
  quantity: number
  quantity_unit?: string | null
  dispensed_quantity?: number | null
  dispensed_brand_id?: number | null
  dispensed_brand_name?: string | null
  frequency: string
  duration: string
  instructions: string | null
}

export interface PrescriptionEvent {
  id: number
  prescription_id: number
  event_type: 'ISSUED' | 'VERIFIED' | 'DISPENSED'
  actor_id: number
  actor?: User
  occurred_at: string
  blockchain_tx_id: string | null
}

export interface Prescription {
  id: number
  reference_no: string
  patient_record_id: number
  doctor_id: number
  patient_record?: PatientRecord
  doctor?: Doctor
  items: PrescriptionItem[]
  events?: PrescriptionEvent[]
  issued_at: string
  status: PrescriptionStatus
  blockchain_tx_id: string | null
  created_at: string
  updated_at: string
}



export type BillingStatus = 'pending' | 'paid' | 'waived'

export interface BillingRecord {
  id: number
  patient_id: number
  appointment_id: number
  patient?: Patient
  appointment?: Appointment
  amount: number
  status: BillingStatus
  paymongo_id: string | null
  paid_at: string | null
  created_at: string
  updated_at: string
}



export interface ActivityLog {
  id: number
  user_id: number
  user?: User
  action: string
  target_type: string
  target_id: number
  ip_address: string | null
  context?: string | null
  created_at: string
}



export interface MedicineBrand {
  id: number
  medicine_id: number
  brand_name: string
  hospital_code: string | null
  strength: string | null
  dosage_form: string | null
  packaging: string | null
  is_available: boolean
}

export interface Medicine {
  id: number
  generic_name: string
  dosage_form: string | null
  is_available: boolean
  strengths?: string[]        // distinct strengths across this generic's brands (dosage dropdown)
  brand_count?: number
  brands?: MedicineBrand[]
}



export interface Paginated<T> {
  data: T[]
  links: {
    first: string | null
    last: string | null
    prev: string | null
    next: string | null
  }
  meta: {
    current_page: number
    last_page: number
    per_page: number
    total: number
    from: number | null
    to: number | null
  }
}
